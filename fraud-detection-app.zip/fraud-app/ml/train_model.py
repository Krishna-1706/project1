# =============================================
# FRAUD DETECTION - ML TRAINING NOTEBOOK
# Copy this into Google Colab cell by cell
# Dataset: Kaggle Credit Card Fraud Detection
# =============================================

# ── CELL 1: Install libraries ──────────────────
# !pip install kaggle xgboost scikit-learn pandas numpy joblib

# ── CELL 2: Download Kaggle dataset ────────────
# Upload your kaggle.json API key to Colab first, then:
# !mkdir -p ~/.kaggle && cp kaggle.json ~/.kaggle/ && chmod 600 ~/.kaggle/kaggle.json
# !kaggle datasets download -d mlg-ulb/creditcardfraud --unzip

# ── CELL 3: Train model ────────────────────────
import pandas as pd
import numpy as np
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.preprocessing import StandardScaler
import joblib

# Load data
df = pd.read_csv("creditcard.csv")
print(f"Dataset: {len(df)} rows | Fraud: {df['Class'].sum()} cases")

# Features & target
X = df.drop(columns=["Class", "Time"])
y = df["Class"]

# Scale Amount (all other cols already PCA'd)
scaler = StandardScaler()
X["Amount"] = scaler.fit_transform(X[["Amount"]])

# Train / test split (stratified to keep fraud ratio)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# XGBoost with scale_pos_weight to handle imbalance
fraud_ratio = (y_train == 0).sum() / (y_train == 1).sum()

model = XGBClassifier(
    n_estimators=200,
    max_depth=6,
    learning_rate=0.1,
    scale_pos_weight=fraud_ratio,   # handles class imbalance
    use_label_encoder=False,
    eval_metric="auc",
    random_state=42
)

model.fit(X_train, y_train,
          eval_set=[(X_test, y_test)],
          verbose=50)

# Evaluate
y_pred  = model.predict(X_test)
y_proba = model.predict_proba(X_test)[:, 1]

print("\n── Classification Report ──")
print(classification_report(y_test, y_pred, target_names=["Legit","Fraud"]))
print(f"ROC-AUC Score: {roc_auc_score(y_test, y_proba):.4f}")

# ── CELL 4: Save model & scaler ────────────────
joblib.dump(model,  "fraud_model.pkl")
joblib.dump(scaler, "scaler.pkl")
print("Saved: fraud_model.pkl and scaler.pkl")

# Download them from Colab sidebar (Files panel)
# Then place both files inside the /backend folder
