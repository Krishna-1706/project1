-- =============================================
-- FRAUD DETECTION APP - SUPABASE SCHEMA
-- Run this in: Supabase Dashboard > SQL Editor
-- =============================================

-- 1. ACCOUNTS TABLE
create table accounts (
  id          uuid primary key default gen_random_uuid(),
  user_name   text not null,
  email       text unique not null,
  balance     numeric(12,2) default 10000.00,
  status      text default 'active' check (status in ('active','frozen')),
  created_at  timestamptz default now()
);

-- 2. TRANSACTIONS TABLE
create table transactions (
  id              uuid primary key default gen_random_uuid(),
  account_id      uuid references accounts(id),
  amount          numeric(10,2) not null,
  merchant        text not null,
  location        text not null,
  device_hash     text,
  risk_score      numeric(4,3) default 0,
  status          text default 'approved' check (status in ('approved','flagged','blocked')),
  created_at      timestamptz default now()
);

-- 3. ALERTS TABLE
create table alerts (
  id             uuid primary key default gen_random_uuid(),
  account_id     uuid references accounts(id),
  transaction_id uuid references transactions(id),
  message        text,
  resolved       boolean default false,
  created_at     timestamptz default now()
);

-- 4. Enable Realtime (for live dashboard updates)
alter publication supabase_realtime add table transactions;
alter publication supabase_realtime add table alerts;

-- 5. Seed demo accounts
insert into accounts (user_name, email, balance) values
  ('Ravi Kumar',   'ravi@demo.com',   50000.00),
  ('Priya Sharma', 'priya@demo.com',  75000.00),
  ('Arjun Reddy',  'arjun@demo.com', 120000.00);
