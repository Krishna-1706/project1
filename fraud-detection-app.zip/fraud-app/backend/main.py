"""
FRAUD DETECTION - FastAPI Backend
Deploy FREE on: render.com
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import joblib
import numpy as np
import os
from supabase import create_client, Client
from datetime import datetime
import httpx

# ── App setup ─────────────────────────────────
app = FastAPI(title="Fraud Detection API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # lock down to your Vercel URL in production
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Load ML model ──────────────────────────────
MODEL_PATH  = os.path.join(os.path.dirname(__file__), "fraud_model.pkl")
SCALER_PATH = os.path.join(os.path.dirname(__file__), "scaler.pkl")

model  = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

# ── Supabase client ────────────────────────────
SUPABASE_URL = os.environ["SUPABASE_URL"]
SUPABASE_KEY = os.environ["SUPABASE_KEY"]
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# ── Request / Response models ──────────────────
class TransactionRequest(BaseModel):
    account_id: str
    amount: float
    merchant: str
    location: str
    device_hash: Optional[str] = "unknown"
    # The 28 PCA features from the Kaggle dataset (V1–V28)
    # For demo mode we generate them randomly if not supplied
    v_features: Optional[list[float]] = None

class TransactionResponse(BaseModel):
    transaction_id: str
    risk_score: float
    status: str          # approved | flagged | blocked
    message: str

# ── Helper: build feature vector ──────────────
def build_features(txn: TransactionRequest) -> np.ndarray:
    if txn.v_features and len(txn.v_features) == 28:
        v = txn.v_features
    else:
        # Demo mode: random PCA features (realistic range)
        rng = np.random.default_rng(seed=int(txn.amount * 100) % 9999)
        v = rng.normal(0, 1, 28).tolist()

    amount_scaled = scaler.transform([[txn.amount]])[0][0]
    features = v + [amount_scaled]          # 29 features total
    return np.array(features).reshape(1, -1)

# ── Helper: decide status from score ──────────
def score_to_status(score: float) -> tuple[str, str]:
    if score >= 0.80:
        return "blocked",  "Transaction blocked — high fraud risk detected."
    elif score >= 0.50:
        return "flagged",  "Transaction flagged for review."
    else:
        return "approved", "Transaction approved."

# ── Routes ─────────────────────────────────────

@app.get("/")
def root():
    return {"status": "Fraud Detection API is running"}


@app.post("/transaction", response_model=TransactionResponse)
async def process_transaction(txn: TransactionRequest):
    """Score a transaction and save it to Supabase."""

    # 1. Score with ML model
    features   = build_features(txn)
    risk_score = float(model.predict_proba(features)[0][1])
    status, message = score_to_status(risk_score)

    # 2. Save transaction
    txn_data = {
        "account_id":  txn.account_id,
        "amount":      txn.amount,
        "merchant":    txn.merchant,
        "location":    txn.location,
        "device_hash": txn.device_hash,
        "risk_score":  round(risk_score, 3),
        "status":      status,
    }
    result = supabase.table("transactions").insert(txn_data).execute()
    txn_id = result.data[0]["id"]

    # 3. If flagged/blocked → freeze account + create alert
    if status in ("flagged", "blocked"):
        if status == "blocked":
            supabase.table("accounts") \
                .update({"status": "frozen"}) \
                .eq("id", txn.account_id) \
                .execute()

        supabase.table("alerts").insert({
            "account_id":     txn.account_id,
            "transaction_id": txn_id,
            "message":        message,
        }).execute()

    return TransactionResponse(
        transaction_id=txn_id,
        risk_score=round(risk_score, 3),
        status=status,
        message=message,
    )


@app.get("/transactions/{account_id}")
def get_transactions(account_id: str):
    """Fetch all transactions for an account."""
    result = supabase.table("transactions") \
        .select("*") \
        .eq("account_id", account_id) \
        .order("created_at", desc=True) \
        .limit(50) \
        .execute()
    return result.data


@app.get("/accounts")
def get_accounts():
    """Fetch all demo accounts."""
    result = supabase.table("accounts").select("*").execute()
    return result.data


@app.get("/alerts")
def get_alerts():
    """Fetch unresolved fraud alerts."""
    result = supabase.table("alerts") \
        .select("*, accounts(user_name), transactions(amount, merchant)") \
        .eq("resolved", False) \
        .order("created_at", desc=True) \
        .execute()
    return result.data


@app.patch("/alerts/{alert_id}/resolve")
def resolve_alert(alert_id: str):
    supabase.table("alerts") \
        .update({"resolved": True}) \
        .eq("id", alert_id) \
        .execute()
    return {"message": "Alert resolved"}


@app.get("/stats")
def get_stats():
    """Dashboard summary stats."""
    txns    = supabase.table("transactions").select("status, risk_score").execute().data
    total   = len(txns)
    flagged = sum(1 for t in txns if t["status"] == "flagged")
    blocked = sum(1 for t in txns if t["status"] == "blocked")
    avg_risk = round(sum(t["risk_score"] for t in txns) / total, 3) if total else 0

    return {
        "total_transactions": total,
        "flagged":            flagged,
        "blocked":            blocked,
        "approved":           total - flagged - blocked,
        "avg_risk_score":     avg_risk,
    }
